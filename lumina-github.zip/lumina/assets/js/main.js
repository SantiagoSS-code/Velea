/**
 * main.js
 * Page interactions: pill alignment, product hover, scroll behaviour.
 */

(function () {
  'use strict';

  /* ── Best Seller pill: align vertically with the badges row ── */
  function alignPill() {
    const badges = document.querySelector('.hero-badges');
    const pill   = document.querySelector('.best-seller-pill');
    if (!badges || !pill) return;

    const heroRect  = document.querySelector('.hero').getBoundingClientRect();
    const badgeRect = badges.getBoundingClientRect();

    const topRelativeToHero = badgeRect.top - heroRect.top;
    const offset = (badgeRect.height - pill.offsetHeight) / 2;
    pill.style.top = Math.max(0, topRelativeToHero + offset) + 'px';
  }

  /* ── Nav: add shadow on scroll ───────────────────────────── */
  function handleNavScroll() {
    const nav = document.querySelector('nav');
    if (!nav) return;
    window.addEventListener('scroll', () => {
      if (window.scrollY > 10) {
        nav.style.boxShadow = '0 2px 24px rgba(0,0,0,0.4)';
      } else {
        nav.style.boxShadow = 'none';
      }
    }, { passive: true });
  }

  /* ── Sticky bar: hide when footer is in view ─────────────── */
  function handleStickyBar() {
    const bar    = document.querySelector('.sticky-bar');
    const footer = document.querySelector('footer');
    if (!bar || !footer) return;

    const obs = new IntersectionObserver(
      ([entry]) => { bar.style.opacity = entry.isIntersecting ? '0' : '1'; },
      { threshold: 0.1 }
    );
    obs.observe(footer);
  }

  /* ── Scroll-reveal: fade sections in on scroll ───────────── */
  function handleScrollReveal() {
    const targets = document.querySelectorAll(
      '.section-card, .phil-card, .proof-section .section-inner, .community-wrap, .review-stats-row'
    );
    if (!targets.length) return;

    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.opacity  = '1';
            entry.target.style.transform = 'translateY(0)';
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08 }
    );

    targets.forEach(el => {
      el.style.opacity   = '0';
      el.style.transform = 'translateY(32px)';
      el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
      obs.observe(el);
    });
  }

  /* ── Init ─────────────────────────────────────────────────── */
  function init() {
    alignPill();
    handleNavScroll();
    handleStickyBar();
    handleScrollReveal();

    // Re-align pill after fonts load
    setTimeout(alignPill, 150);
    window.addEventListener('resize', alignPill, { passive: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
